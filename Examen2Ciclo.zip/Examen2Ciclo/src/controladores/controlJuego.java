
package controladores;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;


public class controlJuego {
    
    
    
   public String esconder(String cadena) {
   int tamMax=cadena.length()-1;
   String st=cadena;
   cadena="";
   String conten="";
   
   for (int i=0;i<tamMax+1;i++){
       conten=conten+""+"X";
   }
   return conten;
   
}  
   
  
}

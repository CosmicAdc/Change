
package controladores;
import com.opencsv.CSVParser;
import com.opencsv.CSVParserBuilder;
import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
         import modelo.Puntuaciones;
public class archivosCSV {
    private String ruta;
    private Puntuaciones punGuarda;
    public archivosCSV(String ruta,Puntuaciones pun) {
        this.ruta = ruta;
        this.punGuarda=pun;
    }
   
    
    public void crear() throws IOException{
                           
            

                 FileWriter escribir = new FileWriter("C:\\Users\\andre\\OneDrive\\Documentos\\2doProgra\\figuras\\Examen2Ciclo\\src\\archivos\\guarda.csv");
               
                 
                 escribir.append(String.valueOf(punGuarda.getNombre())+"\n" );
                 escribir.append(',');
                 
                 escribir.append(String.valueOf(punGuarda.getIntentos())+"\n");
                 escribir.append(',');
                 
                 escribir.append(String.valueOf(punGuarda.getPuntuacion())+"\n");
                 escribir.append(','); 
                 try{
                   for (String i: punGuarda.getListtaPala()){
                    escribir.append(i+"\n");
                    escribir.append(';');  
                 }  
                 }catch(Exception ex){
                     System.out.println("HE");
                 }
                 

                 escribir.close();
        
        
        
        
//            String[] dat= {String.valueOf(punGuarda.getId()),punGuarda.getNombre(),String.valueOf(punGuarda.getIntentos()),String.valueOf(punGuarda.getPuntuacion())};
//             
//            String archCSV = "C:\\Users\\andre\\OneDrive\\Documentos\\2doProgra\\figuras\\Examen2Ciclo\\src\\archivos\\guarda.csv";
//            CSVWriter writer = new CSVWriter(new FileWriter(archCSV));  
//
//            writer.writeNext(dat);
//
//            writer.close();
        
    }
    
    
    
    
    
//    public void leer(){
//          CSVParser conPuntoYComa = new CSVParserBuilder().withSeparator(';').build();
//          CSVReader csvReader = new CSVReader(new FileReader(archCSV));
//          String[] fila = null;
//          while((fila = csvReader.readNext()) != null) {
//              System.out.println(fila[0]
//                          + " | " + fila[1]
//                          + " |  " + fila[2]);
//            }
//
//         csvReader.close();
//    }
//              
    
    
}

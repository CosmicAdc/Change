
package controladores;
import java.io.BufferedReader;
         import java.io.File;
import java.io.FileNotFoundException;
         import java.io.FileWriter;
         import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
         import modelo.palabras;
public class archivosPalabras {
    
     private String ruta;

    public archivosPalabras(String ruta) {
        this.ruta = ruta;
    }

    
    
    public List<palabras> leer() {
        List<palabras> pala = new ArrayList<>();
        try {
            FileReader archivo = new FileReader(this.ruta);
            BufferedReader lectura = new BufferedReader(archivo);
            String Palabras = "";
            while(Palabras != null){
                Palabras = lectura.readLine();
                if (Palabras != null){
                    palabras e = new palabras(Palabras);
                    pala.add(e);
                }
            }
            lectura.close();
            archivo.close();
            return pala;
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return pala;
    }
    
}

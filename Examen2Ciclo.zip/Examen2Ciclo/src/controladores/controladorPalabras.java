
package controladores;

import java.util.ArrayList;
import java.util.List;
import modelo.palabras;


public class controladorPalabras {
     private List<palabras> listaPalabras;
    private palabras seleccionado;
    
    public controladorPalabras(){
        listaPalabras = new ArrayList();
        seleccionado = null;
    }

    public List<palabras> getListaPalabras() {
        return listaPalabras;
    }

    public void setListaPalabras(List<palabras> listaPalabras) {
        this.listaPalabras = listaPalabras;
    }

    public palabras getSeleccionado() {
        return seleccionado;
    }

    public void setSeleccionado(palabras seleccionado) {
        this.seleccionado = seleccionado;
    }

    @Override
    public String toString() {
        return "controladorPalabras{" + "listaPalabras=" + listaPalabras + ", seleccionado=" + seleccionado + '}';
    }
    
    
    
    
}

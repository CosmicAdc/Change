
package controladores;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import modelo.Puntuaciones;

public class controlPuntuaciones {
     private List<Puntuaciones> listaPuntuaciones;
    private Puntuaciones seleccionado;
    
    public controlPuntuaciones(){
        listaPuntuaciones = new ArrayList();
        seleccionado = null;
    }
    
    
    
    public Puntuaciones crear(int id,String nombre,int puntuaciones, int intentos,List<String> S){
    
        Puntuaciones Puntuaciones = new Puntuaciones(id,nombre, intentos, puntuaciones, S);
        System.out.println("---"+Puntuaciones);
        JOptionPane.showMessageDialog(null,"PUNTUACION GUARDADA EXITOSAMENTE");
        listaPuntuaciones.add(Puntuaciones);
        return  Puntuaciones; 
    }

    public List<Puntuaciones> getListaPuntuaciones() {
        return listaPuntuaciones;
    }

    public void setListaPuntuaciones(List<Puntuaciones> listaPuntuaciones) {
        this.listaPuntuaciones = listaPuntuaciones;
    }

    public Puntuaciones getSeleccionado() {
        return seleccionado;
    }

    public void setSeleccionado(Puntuaciones seleccionado) {
        this.seleccionado = seleccionado;
    }

    @Override
    public String toString() {
        return "controlPuntuaciones{" + "listaPuntuaciones=" + listaPuntuaciones + ", seleccionado=" + seleccionado + '}';
    }
    
    
    
}

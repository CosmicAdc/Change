
package controladores;
import java.util.ArrayList;
import java.util.List;
import modelo.Usuario;
public class controlUsuario {
    private List<Usuario> listaUsuario;
    private Usuario seleccionado;
    
    public controlUsuario(){
        listaUsuario = new ArrayList();
        seleccionado = null;
    }
    
    public int generarId(){
        if(listaUsuario.size()>0)
            return listaUsuario.get(listaUsuario.size() -1).getId() + 1;
        return 1;
    }
    
    public Usuario crear(String nombre, int intentos){
        Usuario usuario = new Usuario(generarId(),nombre, intentos);
        listaUsuario.add(usuario);
        return usuario;
    }

    public List<Usuario> getListaUsuario() {
        return listaUsuario;
    }

    public void setListaUsuario(List<Usuario> listaUsuario) {
        this.listaUsuario = listaUsuario;
    }

    public Usuario getSeleccionado() {
        return seleccionado;
    }

    public void setSeleccionado(Usuario seleccionado) {
        this.seleccionado = seleccionado;
    }

    @Override
    public String toString() {
        return "controlUsuario{" + "listaUsuario=" + listaUsuario + ", seleccionado=" + seleccionado + '}';
    }
    
    
    
}

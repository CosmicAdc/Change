/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examen2ciclo;
import controladores.controlUsuario;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import controladores.controlJuego;
import java.util.ArrayList;
import java.util.List;
import modelo.palabras;
public class pJuego extends javax.swing.JInternalFrame {

    private int Puntuacion=0;
    private int intentosN;
    private int posicion=0;
    private String auxPal;
    private int contadorpal;
    private int c=0;
    private int NUEVA=0;
    List<palabras> listaP;
    List<String> acertadas;
    private boolean win=false;
    private  controlJuego controlJ;
    private String U;
    private int id,intentosE;
    public pJuego(int id,String nombre,int intentos,String palabraelegida,List<palabras> lista) {
        acertadas=new ArrayList<String>();
        initComponents();
        controlJ=new controlJuego();
        palabra.setText(palabraelegida);
        palabra.setText(palabra.getText().toUpperCase());
        puntuacion.setText(Puntuacion+" ");
        intentosN=intentos;
        cambio(intentosN);
        INTENTOS.setText(intentosN+" ");
        auxPal=palabra.getText();
        String a=controlJ.esconder(palabra.getText());
        palabra.setText(a);
        contadorpal=palabra.getText().length();
        listaP=lista;
        auxPal=palabraelegida;
        
        U=nombre;
        this.id=id;
        intentosE=intentos;
        
    }
    
     
//public void esconder(String cadena) {
//   int tamMax=cadena.length()-1;
//   palabra.setText("");
//   String conten;
//   
//   for (int i=0;i<tamMax+1;i++){
//       conten=palabra.getText();
//       conten=conten+""+"X";
//       palabra.setText(conten);
//   }
//   
//}  
//    
    
public void cambio(int intentos2){
    if (intentos2==4){
            Icon icono=new ImageIcon(getClass().getResource("/imagenes/el-ahorcado-1.jpg"));
            imagen.setIcon(icono);
        }else if(intentos2==3){
            Icon icono=new ImageIcon(getClass().getResource("/imagenes/el-ahorcado-2.jpg"));
            imagen.setIcon(icono);
        }else if(intentos2==2){
            Icon icono=new ImageIcon(getClass().getResource("/imagenes/el-ahorcado-3.jpg"));
            imagen.setIcon(icono);
        }else if(intentos2==1){
            Icon icono=new ImageIcon(getClass().getResource("/imagenes/el-ahorcado-4.jpg"));
            imagen.setIcon(icono);
        }else if(intentos2==0){
            Icon icono=new ImageIcon(getClass().getResource("/imagenes/el-ahorcado-5.jpg"));
            imagen.setIcon(icono);
        }
}
   
    
    
    public void puntua(){
        Puntuacion=Puntuacion+100;
        puntuacion.setText(Puntuacion+" ");
        c++;
     try{
        
        if(c==contadorpal){
            acertadas.add(auxPal);
            win=true;   
         
            if (listaP.get(NUEVA).getPalabras().equals(auxPal)){
                NUEVA=NUEVA++;
                palabra.setText(listaP.get(NUEVA).getPalabras());
                auxPal=listaP.get(NUEVA).getPalabras();
                String a=controlJ.esconder(palabra.getText());
                
                palabra.setText(a);
                
            }else{
                palabra.setText(listaP.get(NUEVA).getPalabras());
                auxPal=listaP.get(NUEVA).getPalabras();
                System.out.println("CAMBIO POR"+auxPal);
                String a=controlJ.esconder(palabra.getText());
            
                palabra.setText(a);
                NUEVA++;
            }
            JOptionPane.showMessageDialog(null,"FELICIDADES COMPLETASTE LA PALABRA");    
            c=0;
            activar();
            contadorpal=auxPal.length();
           
        }
        }catch(Exception ex){
       
        
    }
       if (Puntuacion>=7900){
              int con=JOptionPane.showConfirmDialog(null,"FELICIDADES OBTUVISTE LA PUNTUACION MÁXIMA");
              if (con==0){
                  nuevoT();
              }
        }
        
     
    }
     public void activar(){
              A.setVisible(true);
              B.setVisible(true);
              C.setVisible(true);
              D.setVisible(true);
              E.setVisible(true);
              F.setVisible(true);
              G.setVisible(true);
              H.setVisible(true);
              I.setVisible(true);
              J.setVisible(true);
              K.setVisible(true);
              L.setVisible(true);
              M.setVisible(true);
              N.setVisible(true);
              O.setVisible(true);
              P.setVisible(true);
              Q.setVisible(true);
              R.setVisible(true);
              S.setVisible(true);
              T.setVisible(true);
              U1.setVisible(true);
              V.setVisible(true);
              W.setVisible(true);
              X.setVisible(true);
              Y.setVisible(true);
              Z.setVisible(true);
   
    
              A.setEnabled(true);
              B.setEnabled(true);
              C.setEnabled(true);
              D.setEnabled(true);
              E.setEnabled(true);
              F.setEnabled(true);
              G.setEnabled(true);
              H.setEnabled(true);
              I.setEnabled(true);
              J.setEnabled(true);
              K.setEnabled(true);
              L.setEnabled(true);
              M.setEnabled(true);
              N.setEnabled(true);
              O.setEnabled(true);
              P.setEnabled(true);
              Q.setEnabled(true);
              R.setEnabled(true);
              S.setEnabled(true);
              T.setEnabled(true);
              U1.setEnabled(true);
              V.setEnabled(true);
              W.setEnabled(true);
              X.setEnabled(true);
              Y.setEnabled(true);
              Z.setEnabled(true);
      }
    
    public void intento(String letra){ 
        int b=auxPal.length();
        String tex=auxPal;
        ingreso.setText(letra);
        String text=palabra.getText();
        boolean correcto=false;
        char cad;
        char[] charArray = text.toCharArray();
        char charLetra=letra.charAt(0);
        try{
           for(int i=0;i<b;i++){
          cad = tex.charAt(i);               
           if (cad==charLetra){   
                charArray[i] = charLetra;
                String newString = String.valueOf(charArray);
                
                puntua();
                correcto=true;         
           }   
        } 
           if (win==false){
                palabra.setText(String.valueOf(charArray));  
           }else{
               activar();
               win=false;
           }
          
        
      
        }catch(Exception ex){
            System.out.println("he");
        }
        if (correcto==false){
          intentosN=intentosN-1;
          cambio(intentosN);
          INTENTOS.setText(intentosN+"");
          if (intentosN==0){
              int con=JOptionPane.showConfirmDialog(null,"HAZ PERDIDO DESEAS GUARDAR TU PUNTAJE");
               if (con==0){
                  nuevoT();
              }
              A.setEnabled(false);
              B.setEnabled(false);
              C.setEnabled(false);
              D.setEnabled(false);
              E.setEnabled(false);
              F.setEnabled(false);
              G.setEnabled(false);
              H.setEnabled(false);
              I.setEnabled(false);
              J.setEnabled(false);
              K.setEnabled(false);
              L.setEnabled(false);
              M.setEnabled(false);
              N.setEnabled(false);
              O.setEnabled(false);
              P.setEnabled(false);
              Q.setEnabled(false);
              R.setEnabled(false);
              S.setEnabled(false);
              T.setEnabled(false);
              U1.setEnabled(false);
              V.setEnabled(false);
              W.setEnabled(false);
              X.setEnabled(false);
              Y.setEnabled(false);
              Z.setEnabled(false);
          }
          
        }else{
           correcto=false; 
   
        }
        cambio(intentosN);
    }
    
    
    
    public void nuevoT(){
         pPuntuaciones pP= new pPuntuaciones(this.id,U,intentosE,Puntuacion,acertadas);
         pInicio.panPrinci.add(pP);
         pP.show();
        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        palabra = new javax.swing.JTextField();
        imagen = new javax.swing.JLabel();
        A = new javax.swing.JButton();
        B = new javax.swing.JButton();
        C = new javax.swing.JButton();
        D = new javax.swing.JButton();
        E = new javax.swing.JButton();
        F = new javax.swing.JButton();
        G = new javax.swing.JButton();
        H = new javax.swing.JButton();
        I = new javax.swing.JButton();
        J = new javax.swing.JButton();
        K = new javax.swing.JButton();
        L = new javax.swing.JButton();
        M = new javax.swing.JButton();
        N = new javax.swing.JButton();
        O = new javax.swing.JButton();
        P = new javax.swing.JButton();
        Q = new javax.swing.JButton();
        R = new javax.swing.JButton();
        S = new javax.swing.JButton();
        T = new javax.swing.JButton();
        V = new javax.swing.JButton();
        W = new javax.swing.JButton();
        X = new javax.swing.JButton();
        Y = new javax.swing.JButton();
        Z = new javax.swing.JButton();
        ingreso = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        puntuacion = new javax.swing.JTextField();
        CERRAR = new javax.swing.JButton();
        INTENTOS = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        U1 = new javax.swing.JButton();

        palabra.setEditable(false);
        palabra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                palabraActionPerformed(evt);
            }
        });

        imagen.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/el-ahorcado-1.jpg"))); // NOI18N

        A.setText("A");
        A.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AActionPerformed(evt);
            }
        });

        B.setText("B");
        B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BActionPerformed(evt);
            }
        });

        C.setText("C");
        C.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CActionPerformed(evt);
            }
        });

        D.setText("D");
        D.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DActionPerformed(evt);
            }
        });

        E.setText("E");
        E.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EActionPerformed(evt);
            }
        });

        F.setText("F");
        F.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FActionPerformed(evt);
            }
        });

        G.setText("G");
        G.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GActionPerformed(evt);
            }
        });

        H.setText("H");
        H.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HActionPerformed(evt);
            }
        });

        I.setText("I");
        I.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IActionPerformed(evt);
            }
        });

        J.setText("J");
        J.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JActionPerformed(evt);
            }
        });

        K.setText("K");
        K.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KActionPerformed(evt);
            }
        });

        L.setText("L");
        L.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LActionPerformed(evt);
            }
        });

        M.setText("M");
        M.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MActionPerformed(evt);
            }
        });

        N.setText("N");
        N.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NActionPerformed(evt);
            }
        });

        O.setText("O");
        O.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OActionPerformed(evt);
            }
        });

        P.setText("P");
        P.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PActionPerformed(evt);
            }
        });

        Q.setText("Q");
        Q.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                QActionPerformed(evt);
            }
        });

        R.setText("R");
        R.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RActionPerformed(evt);
            }
        });

        S.setText("S");
        S.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SActionPerformed(evt);
            }
        });

        T.setText("T");
        T.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TActionPerformed(evt);
            }
        });

        V.setText("V");
        V.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VActionPerformed(evt);
            }
        });

        W.setText("W");
        W.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                WActionPerformed(evt);
            }
        });

        X.setText("X");
        X.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                XActionPerformed(evt);
            }
        });

        Y.setText("Y");
        Y.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                YActionPerformed(evt);
            }
        });

        Z.setText("Z");
        Z.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ZActionPerformed(evt);
            }
        });

        ingreso.setEditable(false);
        ingreso.setFont(new java.awt.Font("Trebuchet MS", 0, 24)); // NOI18N
        ingreso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ingresoActionPerformed(evt);
            }
        });

        jLabel1.setText("INGRESO");

        jLabel2.setText("PUNTAJE");

        puntuacion.setEditable(false);
        puntuacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                puntuacionActionPerformed(evt);
            }
        });

        CERRAR.setText("CERRAR");
        CERRAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CERRARActionPerformed(evt);
            }
        });

        INTENTOS.setFont(new java.awt.Font("Tw Cen MT", 0, 24)); // NOI18N
        INTENTOS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                INTENTOSActionPerformed(evt);
            }
        });

        jLabel3.setText("INTENTOS");

        U1.setText("U");
        U1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                U1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(O)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(P)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(Q)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(R)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(S)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(T))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(H)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(I)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(J)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(K)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(L)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(M)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(N))))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(28, 28, 28)
                                    .addComponent(A))
                                .addGroup(layout.createSequentialGroup()
                                    .addContainerGap()
                                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                    .addGap(6, 6, 6)
                                    .addComponent(puntuacion, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(INTENTOS, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(4, 4, 4)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(B)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(C)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(D)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(E)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(F)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(G))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(19, 19, 19)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(palabra, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(imagen))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(33, 33, 33)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(ingreso, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(18, 18, 18)
                                        .addComponent(CERRAR))))))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(U1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(V)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(W)
                        .addGap(18, 18, 18)
                        .addComponent(X)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Y)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Z)))
                .addContainerGap(32, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addComponent(CERRAR, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ingreso, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(palabra, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(imagen))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(puntuacion, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(INTENTOS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(A)
                    .addComponent(B)
                    .addComponent(C)
                    .addComponent(D)
                    .addComponent(E)
                    .addComponent(F)
                    .addComponent(G))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(H)
                    .addComponent(I)
                    .addComponent(J)
                    .addComponent(K)
                    .addComponent(L)
                    .addComponent(M)
                    .addComponent(N))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(O)
                    .addComponent(P)
                    .addComponent(Q)
                    .addComponent(R)
                    .addComponent(S)
                    .addComponent(T))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(V)
                    .addComponent(W)
                    .addComponent(X)
                    .addComponent(Y)
                    .addComponent(Z)
                    .addComponent(U1))
                .addGap(0, 33, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void palabraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_palabraActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_palabraActionPerformed

    private void AActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AActionPerformed
        A.setVisible(false);
        intento(A.getText());
    
    }//GEN-LAST:event_AActionPerformed

    private void BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BActionPerformed
         B.setVisible(false);
        intento(B.getText());
       
    }//GEN-LAST:event_BActionPerformed

    private void PActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PActionPerformed
        P.setVisible(false);
        intento(P.getText());
       
    }//GEN-LAST:event_PActionPerformed

    private void puntuacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_puntuacionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_puntuacionActionPerformed

    private void ingresoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ingresoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ingresoActionPerformed

    private void CActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CActionPerformed
          C.setVisible(false);
        intento(C.getText());
      
    }//GEN-LAST:event_CActionPerformed

    private void DActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DActionPerformed
        D.setVisible(false);
        intento(D.getText());
      
    }//GEN-LAST:event_DActionPerformed

    private void EActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EActionPerformed
        E.setVisible(false);
        intento(E.getText());
      
    }//GEN-LAST:event_EActionPerformed

    private void FActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FActionPerformed
             F.setVisible(false);
        intento(F.getText());
 
    }//GEN-LAST:event_FActionPerformed

    private void GActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GActionPerformed
          G.setVisible(false);
        intento(G.getText());
      
    }//GEN-LAST:event_GActionPerformed

    private void HActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HActionPerformed
         H.setVisible(false); 
        intento(H.getText());
             // TODO add your handling code here:
    }//GEN-LAST:event_HActionPerformed

    private void IActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IActionPerformed
       
          I.setVisible(false);
        intento(I.getText());
      
    }//GEN-LAST:event_IActionPerformed

    private void JActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JActionPerformed
         J.setVisible(false);
        intento(J.getText());
       
    }//GEN-LAST:event_JActionPerformed

    private void KActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KActionPerformed
           K.setVisible(false);
        intento(K.getText());
     
    }//GEN-LAST:event_KActionPerformed

    private void LActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LActionPerformed
        L.setVisible(false);
        intento(L.getText());
      
    }//GEN-LAST:event_LActionPerformed

    private void MActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MActionPerformed
        M.setVisible(false);
        intento(M.getText());
        
    }//GEN-LAST:event_MActionPerformed

    private void NActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NActionPerformed
      N.setVisible(false);
        intento(N.getText());
      
    }//GEN-LAST:event_NActionPerformed

    private void OActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OActionPerformed
         O.setVisible(false);
        intento(O.getText());
       
    }//GEN-LAST:event_OActionPerformed

    private void QActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_QActionPerformed
            Q.setVisible(false);
        intento(Q.getText());
    
    }//GEN-LAST:event_QActionPerformed

    private void RActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RActionPerformed
               R.setVisible(false);
        intento(R.getText());

    }//GEN-LAST:event_RActionPerformed

    private void SActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SActionPerformed
           S.setVisible(false);
        intento(S.getText());
     
    }//GEN-LAST:event_SActionPerformed

    private void TActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TActionPerformed
        T.setVisible(false);
        intento(T.getText());
       
    }//GEN-LAST:event_TActionPerformed

    private void VActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VActionPerformed
         V.setVisible(false);
        intento(V.getText());
       
    }//GEN-LAST:event_VActionPerformed

    private void WActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_WActionPerformed
         W.setVisible(false);
        intento(W.getText());
       
    }//GEN-LAST:event_WActionPerformed

    private void XActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_XActionPerformed
             X.setVisible(false);
        intento(X.getText());
   
    }//GEN-LAST:event_XActionPerformed

    private void YActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_YActionPerformed
          Y.setVisible(false);
        intento(Y.getText());
      
    }//GEN-LAST:event_YActionPerformed

    private void ZActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ZActionPerformed
                Z.setVisible(false);
        intento(Z.getText());

    }//GEN-LAST:event_ZActionPerformed

    private void CERRARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CERRARActionPerformed
        this.dispose();
    }//GEN-LAST:event_CERRARActionPerformed

    private void INTENTOSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_INTENTOSActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_INTENTOSActionPerformed

    private void U1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_U1ActionPerformed
        U1.setVisible(false);
        intento("U");
    }//GEN-LAST:event_U1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton A;
    private javax.swing.JButton B;
    private javax.swing.JButton C;
    private javax.swing.JButton CERRAR;
    private javax.swing.JButton D;
    private javax.swing.JButton E;
    private javax.swing.JButton F;
    private javax.swing.JButton G;
    private javax.swing.JButton H;
    private javax.swing.JButton I;
    private javax.swing.JTextField INTENTOS;
    private javax.swing.JButton J;
    private javax.swing.JButton K;
    private javax.swing.JButton L;
    private javax.swing.JButton M;
    private javax.swing.JButton N;
    private javax.swing.JButton O;
    private javax.swing.JButton P;
    private javax.swing.JButton Q;
    private javax.swing.JButton R;
    private javax.swing.JButton S;
    private javax.swing.JButton T;
    private javax.swing.JButton U1;
    private javax.swing.JButton V;
    private javax.swing.JButton W;
    private javax.swing.JButton X;
    private javax.swing.JButton Y;
    private javax.swing.JButton Z;
    public javax.swing.JLabel imagen;
    private javax.swing.JTextField ingreso;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JTextField palabra;
    private javax.swing.JTextField puntuacion;
    // End of variables declaration//GEN-END:variables
}

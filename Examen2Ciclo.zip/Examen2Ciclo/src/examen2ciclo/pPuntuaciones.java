
package examen2ciclo;
import controladores.archivosCSV;
    import java.io.File;
    import java.io.FileWriter;
    import java.io.FileReader;
import modelo.Puntuaciones;
    import controladores.controlPuntuaciones;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
    import javax.swing.table.DefaultTableModel;
public class pPuntuaciones extends javax.swing.JInternalFrame {
    
    private int posicion;
    private controlPuntuaciones ctrPuntuaciones;
    int id;
    String nombre; 
    int puntuaciones;
    int intentos;
    int c=0;
    List<String> S;
    
    public pPuntuaciones(int id,String nombre,int puntuaciones, int intentos,List<String> S) {
        initComponents();
        ctrPuntuaciones= new controlPuntuaciones();
        model=(DefaultTableModel)this.tablaPuntuaciones.getModel();
        crear();
        this.id=id;
        this.nombre=nombre;
        this.puntuaciones=puntuaciones;
        this.intentos=intentos;
        this.S=S;
        
        cargarDatos();
    }
    
    
    
    public void crear(){
        ctrPuntuaciones.crear(id, nombre, puntuaciones, intentos, S);
        
    }
    
      public void cargarDatos(){
        model.setRowCount(0);
        for (modelo.Puntuaciones puntuacion : ctrPuntuaciones.getListaPuntuaciones()) {
            String datos[] = {String.valueOf(id), nombre,String.valueOf(intentos),String.valueOf(puntuaciones)};
            model.addRow(datos);
        }
      
    }
      

    
      
      
//    public void cargarElemento(int posicion){
//        this.posicion = posicion;
//        if(posicion >= 0){
//            Empresa empresa = empresaControlador.getListaEmpresa().get(posicion);
//            txtNombre.setText(empresa.getNombre());
//        }else {
//            txtNombre.setText("");
//        }
//    }
    

     DefaultTableModel model;
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaPuntuaciones = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();

        jLabel1.setFont(new java.awt.Font("Tw Cen MT", 0, 24)); // NOI18N
        jLabel1.setText("TABLA DE PUNTUACIONES");

        tablaPuntuaciones.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        tablaPuntuaciones.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "NOMBRE", "ACIERTOS", "INTENTOS"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tablaPuntuaciones);
        if (tablaPuntuaciones.getColumnModel().getColumnCount() > 0) {
            tablaPuntuaciones.getColumnModel().getColumn(0).setResizable(false);
            tablaPuntuaciones.getColumnModel().getColumn(1).setResizable(false);
            tablaPuntuaciones.getColumnModel().getColumn(2).setResizable(false);
            tablaPuntuaciones.getColumnModel().getColumn(3).setResizable(false);
        }

        jButton1.setText("CREAR ARCHIVO CSV");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton3.setText("CERRAR");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(60, 60, 60))
            .addGroup(layout.createSequentialGroup()
                .addGap(75, 75, 75)
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 362, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 381, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, 33, Short.MAX_VALUE)
                    .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        Puntuaciones puntua = ctrPuntuaciones.crear(id, nombre, puntuaciones, intentos, S);
        archivosCSV archivo= new archivosCSV("C:/",puntua);
        try {  
            archivo.crear();
        } catch (IOException ex) {
            Logger.getLogger(pPuntuaciones.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        this.dispose();
    }//GEN-LAST:event_jButton3ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaPuntuaciones;
    // End of variables declaration//GEN-END:variables
}

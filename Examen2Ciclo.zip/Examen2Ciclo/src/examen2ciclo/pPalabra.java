/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examen2ciclo;
    import java.io.File;
    import java.io.FileWriter;
    import java.io.FileReader;
    import javax.swing.table.DefaultTableModel;
    import controladores.archivosPalabras;
    import controladores.controladorPalabras;
    import modelo.Usuario;
    import controladores.controlUsuario;
    import modelo.palabras;
    import javax.swing.event.ListSelectionEvent;
    import javax.swing.event.ListSelectionListener;
    public class pPalabra extends javax.swing.JInternalFrame {
        
    private archivosPalabras archivoTexto,archivoEsc;
    private controladorPalabras cPalabras,cPalabras2;
    private DefaultTableModel model;
    private int posicion;
    
    private boolean b=false;
    private String palSelecc;
    private String nom;
    private int id;
    private int intentos;
    
    
    
    
    public pPalabra(Usuario usu) {
        
        initComponents();
        model=(DefaultTableModel) this.tablaP.getModel();
        nom=usu.getNombre();
        id=usu.getId();
        intentos=usu.getIntentos();
        cPalabras= new controladorPalabras();
        cPalabras2= new controladorPalabras();
        archivoTexto = new archivosPalabras("/Users/andre/OneDrive/Documentos/2doProgra/figuras/Examen2Ciclo/src/archivos/palabras.txt");
        archivoEsc = new archivosPalabras("/Users/andre/OneDrive/Documentos/2doProgra/figuras/Examen2Ciclo/src/archivos/escondidas.txt");
        this.cargarDatos();
        cPalabras.setListaPalabras(archivoEsc.leer());
        cPalabras2.setListaPalabras(archivoTexto.leer());
        txtNombre.setVisible(false);
        this.cargarDatos(); 
        
         tablaP.getSelectionModel().addListSelectionListener(new ListSelectionListener() {            
            public void valueChanged(ListSelectionEvent lse) {
                cargarElemento(tablaP.getSelectedRow());
                palSelecc=txtNombre.getText();
                System.out.println("Selecciono "+palSelecc);
                
            }
        });
         
        b=true;
        //System.out.println("LLEGO "+usu.getNombre()+usu.getId()+usu.getIntentos());
       
    }
    public pPalabra() {
       
        initComponents();
        jugar.setVisible(false);
        model=(DefaultTableModel) this.tablaP.getModel();
        cPalabras= new controladorPalabras();
        txtNombre.setVisible(false);
        archivoTexto = new archivosPalabras("/Users/andre/OneDrive/Documentos/2doProgra/figuras/Examen2Ciclo/src/archivos/palabras.txt");
        this.cargarDatos();
        cPalabras.setListaPalabras(archivoTexto.leer());
        this.cargarDatos();
        System.out.println("LLISTA"+cPalabras.getListaPalabras());
    }
    
    
    
    
    
  public void cargarDatos(){
        model.setRowCount(0);
        for (modelo.palabras pal : cPalabras.getListaPalabras()) {
            String datos[] = {pal.getPalabras()};
            model.addRow(datos);
        }
    }
  public void cargarElemento(int posicion){
        this.posicion = posicion;
        if(posicion >= 0){
            
           palabras pala = cPalabras2.getListaPalabras().get(posicion);
            palabras pal = cPalabras.getListaPalabras().get(posicion);
            
             if (b==true){
                 txtNombre.setText(pala.getPalabras());
            }else{
                 txtNombre.setText(pal.getPalabras());
             }
            
        }else {
            txtNombre.setText("");
        }
    }
   
  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tablaP = new javax.swing.JTable();
        Cerrar = new javax.swing.JButton();
        txtNombre = new javax.swing.JTextField();
        jugar = new javax.swing.JButton();

        jLabel1.setFont(new java.awt.Font("Tw Cen MT", 0, 14)); // NOI18N
        jLabel1.setText("PALABRAS DISPONIBLES EN EL JUEGO");

        jLabel2.setFont(new java.awt.Font("Tw Cen MT", 0, 14)); // NOI18N
        jLabel2.setText("TEMATICA ESCENARIO DE PELICULAS");

        tablaP.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Palabras"
            }
        ));
        tablaP.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jScrollPane2.setViewportView(tablaP);

        Cerrar.setText("CERRAR");
        Cerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CerrarActionPerformed(evt);
            }
        });

        txtNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreActionPerformed(evt);
            }
        });

        jugar.setText("JUGAR");
        jugar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jugarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jugar, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Cerrar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(22, 22, 22))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Cerrar)
                    .addComponent(jugar)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtNombre))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(51, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void CerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CerrarActionPerformed
        this.dispose();
    }//GEN-LAST:event_CerrarActionPerformed

    private void jugarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jugarActionPerformed
              pJuego pJ= new pJuego(id,nom,intentos,txtNombre.getText(),cPalabras2.getListaPalabras() );
              pInicio.panPrinci.add(pJ);
              pJ.show();        

        
    }//GEN-LAST:event_jugarActionPerformed

    private void txtNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Cerrar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton jugar;
    private javax.swing.JTable tablaP;
    private javax.swing.JTextField txtNombre;
    // End of variables declaration//GEN-END:variables
}


package modelo;

public class palabras {
    
    
    private String palabras;

    public palabras(String palabras) {
        this.palabras = palabras;
    }

  

    public String getPalabras() {
        return palabras;
    }

    public void setPalabras(String palabras) {
        this.palabras = palabras;
    }

    @Override
    public String toString() {
        return "palabras{" + "palabras=" + palabras + '}';
    }
    
    
    
    
}

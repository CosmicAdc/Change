
package modelo;

import java.util.List;

public class Puntuaciones {
    private int id,intentos,puntuacion;
    private String nombre;
    private List <String>  listtaPala;

    public Puntuaciones(int id ,String nombre, int intentos, int puntuacion, List<String> listtaPala) {
        this.id = id;
        this.intentos = intentos;
        this.puntuacion = puntuacion;
        this.nombre = nombre;
        this.listtaPala = listtaPala;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIntentos() {
        return intentos;
    }

    public void setIntentos(int intentos) {
        this.intentos = intentos;
    }

    public int getPuntuacion() {
        return puntuacion;
    }

    public void setPuntuacion(int puntuacion) {
        this.puntuacion = puntuacion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public List<String> getListtaPala() {
        return listtaPala;
    }

    public void setListtaPala(List<String> listtaPala) {
        this.listtaPala = listtaPala;
    }

    @Override
    public String toString() {
        return "PUNTUACIONES{" + "id=" + id + ", intentos=" + intentos + ", puntuacion=" + puntuacion + ", nombre=" + nombre + ", listtaPala=" + listtaPala + '}';
    }

    
    
    
}
